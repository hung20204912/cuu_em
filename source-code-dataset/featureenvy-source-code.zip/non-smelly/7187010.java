        public UpdateSubscriptionRequest build() {
            UpdateSubscriptionRequest request = buildWithoutInvocationCallback();
            request.setInvocationCallback(invocationCallback);
            return request;
        }
