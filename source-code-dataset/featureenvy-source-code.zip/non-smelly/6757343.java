    @Override
    public APIRequestCreateSpacoDataSetCollection setParams(Map<String, Object> params) {
      setParamsInternal(params);
      return this;
    }
