    public final void mKW_Import() throws RecognitionException {
        try {
            int _type = KW_Import;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            {
            match("import"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
