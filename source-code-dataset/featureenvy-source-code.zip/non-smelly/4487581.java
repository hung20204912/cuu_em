    public static org.apache.drill.exec.proto.UserProtos.GetQueryPlanFragments parseFrom(
        com.google.protobuf.ByteString data)
        throws com.google.protobuf.InvalidProtocolBufferException {
      return PARSER.parseFrom(data);
    }
