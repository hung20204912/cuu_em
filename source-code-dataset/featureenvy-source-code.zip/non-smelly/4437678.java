    public LaterunEvent(String clusterName, String wfId, String parentId, long msgInsertTime,
                        long delay, String entityType, String entityName,
                        String instance, int runId, String workflowUser) {
        super(clusterName, wfId, parentId, msgInsertTime, delay, entityType, entityName,
                instance, runId, workflowUser);
    }
