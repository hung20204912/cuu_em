  @Override
  public CsdlProperty setDefaultValue(String defaultValue) {
    this.defaultValue = defaultValue;
    return this;
  }
