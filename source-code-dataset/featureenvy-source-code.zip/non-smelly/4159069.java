    @java.lang.Override
    protected com.google.protobuf.GeneratedMessageV3.FieldAccessorTable
        internalGetFieldAccessorTable() {
      return org.apache.calcite.avatica.proto.Requests.internal_static_CatalogsRequest_fieldAccessorTable
          .ensureFieldAccessorsInitialized(
              org.apache.calcite.avatica.proto.Requests.CatalogsRequest.class, org.apache.calcite.avatica.proto.Requests.CatalogsRequest.Builder.class);
    }
