    @Override
    public String toString() {
        return "JCachePolicy{"
                + "keyExpression=" + keyExpression
                + ", enabled=" + enabled
                + '}';
    }
