        @Override
        public int getDefaultBackgroundColor()
        {
            return 0;
        }
