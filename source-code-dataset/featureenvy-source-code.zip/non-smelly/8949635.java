  public void setWmCountersDone() {
    if (wmCounters != null) {
      wmCounters.changeStateDone();
    }
  }
