    public deleteExperiment_result setSuccess(boolean success) {
      this.success = success;
      setSuccessIsSet(true);
      return this;
    }
