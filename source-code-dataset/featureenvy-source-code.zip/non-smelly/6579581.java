  @Override
  protected EClass eStaticClass()
  {
    return DomainmodelPackage.Literals.OPERATION;
  }
