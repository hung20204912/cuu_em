    @Override
    public BODY<T> $onclick(String value) {
      addAttr("onclick", value);
      return this;
    }
