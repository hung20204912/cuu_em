    public hasNamespacePermission_args setTblNspcPerm(byte tblNspcPerm) {
      this.tblNspcPerm = tblNspcPerm;
      setTblNspcPermIsSet(true);
      return this;
    }
