    public getSiteConfiguration_args(
      java.nio.ByteBuffer login)
    {
      this();
      this.login = org.apache.thrift.TBaseHelper.copyBinary(login);
    }
