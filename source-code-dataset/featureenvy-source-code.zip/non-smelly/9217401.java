        public DTMAxisIterator reset()
        {
            _source.reset();
            return resetPosition();
        }
