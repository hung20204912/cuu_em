    private void initFields() {
      poolId_ = "";
      blockId_ = 0L;
      numBytes_ = 0L;
      generationStamp_ = 0L;
    }
