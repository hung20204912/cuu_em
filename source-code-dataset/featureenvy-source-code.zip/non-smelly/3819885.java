    @org.apache.thrift.annotation.Nullable
    public java.lang.Object getFieldValue(_Fields field) {
      switch (field) {
      case CONDITIONAL_WRITER:
        return getConditionalWriter();

      case UPDATES:
        return getUpdates();

      }
      throw new java.lang.IllegalStateException();
    }
