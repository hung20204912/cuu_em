    public final void synpred200_InternalN4JSParser_fragment() throws RecognitionException {   
        {
        {
        {
        {
        pushFollow(FOLLOW_2);
        ruleEqualityOperator();

        state._fsp--;
        if (state.failed) return ;

        }


        }


        }


        }
    }
