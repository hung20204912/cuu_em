    @Override
    public boolean hasMembers() {
        if (membership == null ) return false;
        return membership.hasMembers();
    }
