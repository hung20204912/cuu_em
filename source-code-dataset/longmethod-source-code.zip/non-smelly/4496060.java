        public static java.lang.String getFieldName(int number)
        {
            switch(number)
            {
                case 1: return "minorType";
                case 2: return "mode";
                case 3: return "width";
                case 4: return "precision";
                case 5: return "scale";
                case 6: return "timeZone";
                case 7: return "subType";
                default: return null;
            }
        }
