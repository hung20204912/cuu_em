    public void setIreIsSet(boolean value) {
      if (!value) {
        this.ire = null;
      }
    }
