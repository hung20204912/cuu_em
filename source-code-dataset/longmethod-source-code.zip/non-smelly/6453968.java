    @Override
    public int hashCode ()
    {
        final int prime = 31;
        int result = 1;
        result = prime * result + ( this.predicate == null ? 0 : this.predicate.hashCode () );
        return result;
    }
