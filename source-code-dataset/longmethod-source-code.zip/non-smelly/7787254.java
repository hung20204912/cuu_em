	@Override
	public List<String> getSuffixes()
	{
		return Arrays.asList("css");
	}
