   public void resetHistory() {
      int max = dayCounterMax;

      setHistoryLimit(0);
      setHistoryLimit(max);
   }
