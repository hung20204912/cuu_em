    @Nonnull
    @Override
    public RetrieveFeaturesLiveCommandAnswerBuilder answer() {
        return RetrieveFeaturesLiveCommandAnswerBuilderImpl.newInstance(this);
    }
