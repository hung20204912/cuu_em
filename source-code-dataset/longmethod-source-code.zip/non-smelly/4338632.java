    @Override
    public boolean canVisit( ExprNode node )
    {
        return node instanceof BranchNode;
    }
