  @CanIgnoreReturnValue
  @Override
  public E remove(int index) {
    return delegate().remove(index);
  }
