    public final void mThis_1() throws RecognitionException {
        try {
            int _type = This_1;
            int _channel = DEFAULT_TOKEN_CHANNEL;
            // InternalTypesLexer.g:131:8: ( 'this' )
            // InternalTypesLexer.g:131:10: 'this'
            {
            match("this"); 


            }

            state.type = _type;
            state.channel = _channel;
        }
        finally {
        }
    }
