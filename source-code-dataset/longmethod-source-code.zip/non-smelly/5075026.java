    @Override
    public long size()
    {
        return currentSize ;
//        long x = 0 ;
//        for ( K key : keys )
//            if ( key != null )
//                x++ ;
//        return x ;
    }
