    @SuppressWarnings("deprecation")
    public void show() {
        Component component = getComponent();

        if (component != null) {
            component.show();
        }
    }
