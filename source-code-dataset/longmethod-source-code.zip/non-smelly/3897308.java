    @org.apache.thrift.annotation.Nullable
    public java.lang.Object getFieldValue(_Fields field) {
      switch (field) {
      case SEC:
        return getSec();

      case TOPE:
        return getTope();

      }
      throw new java.lang.IllegalStateException();
    }
