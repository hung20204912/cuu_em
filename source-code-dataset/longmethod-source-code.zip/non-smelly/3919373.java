    public void setOuch2IsSet(boolean value) {
      if (!value) {
        this.ouch2 = null;
      }
    }
