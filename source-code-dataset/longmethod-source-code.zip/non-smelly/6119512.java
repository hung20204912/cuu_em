        @Override
        public boolean accept(Object anObject)
        {
            return !this.collection.contains(anObject);
        }
