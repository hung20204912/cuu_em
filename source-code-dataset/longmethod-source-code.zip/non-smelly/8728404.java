    public void setAeIsSet(boolean value) {
      if (!value) {
        this.ae = null;
      }
    }
