    @Override
    public void activate()
        throws ActivationException
    {
        activation.activate( applicationModel.newActivatorsInstance(), layerInstances );
    }
