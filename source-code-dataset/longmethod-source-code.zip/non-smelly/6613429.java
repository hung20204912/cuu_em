  @Override
  protected void onDestroy() {
    super.onDestroy();
    mMapView.dispose();
  }
