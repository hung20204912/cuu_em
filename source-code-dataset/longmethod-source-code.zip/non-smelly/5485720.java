    @Override
    public String getTrustedCaDb()
    {
        return _trustedCaDb;
    }
