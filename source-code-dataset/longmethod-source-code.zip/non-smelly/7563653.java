		@Override
		@Nullable
		public Class<?> getBeanType() {
			return this.adviceBean.getBeanType();
		}
