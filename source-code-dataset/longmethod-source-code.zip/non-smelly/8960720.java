    public void setSuccessIsSet(boolean value) {
      if (!value) {
        this.success = null;
      }
    }
