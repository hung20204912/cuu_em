public class ManifestReadingException extends RuntimeException
{

    public ManifestReadingException()
    {
        super();
    }


    public ManifestReadingException( String message, Throwable cause )
    {
        super( message, cause );
    }


    public ManifestReadingException( String message )
    {
        super( message );
    }


    public ManifestReadingException( Throwable cause )
    {
        super( cause );
    }
}
