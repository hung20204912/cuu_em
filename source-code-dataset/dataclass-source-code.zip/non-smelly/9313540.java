public class BC_iflt extends JTTTest {

    public static int test(int a) {
        int n = 0;
        if (a < 0) {
            n += 1;
        } else {
            n -= 1;
        }
        if (a >= 0) {
            n -= 1;
        } else {
            n += 1;
        }
        return n;
    }

    @Test
    public void run0() throws Throwable {
        runTest("test", 0);
    }

    @Test
    public void run1() throws Throwable {
        runTest("test", 1);
    }

    @Test
    public void run2() throws Throwable {
        runTest("test", -1);
    }

}
