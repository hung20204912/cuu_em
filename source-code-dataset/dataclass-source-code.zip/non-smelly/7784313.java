@Singleton
public class MyService implements IMyService
{
	@Override
	public String getHelloWorldText()
	{
		return "Hello World";
	}
}
