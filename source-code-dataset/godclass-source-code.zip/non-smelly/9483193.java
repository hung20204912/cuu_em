@Private
@Stable
public abstract class RefreshUserToGroupsMappingsRequest {
  @Public
  @Stable
  public static RefreshUserToGroupsMappingsRequest newInstance() {
    RefreshUserToGroupsMappingsRequest request =
        Records.newRecord(RefreshUserToGroupsMappingsRequest.class);
    return request;
  }
}
